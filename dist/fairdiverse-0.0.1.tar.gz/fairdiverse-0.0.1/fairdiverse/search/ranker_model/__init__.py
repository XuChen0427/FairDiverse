from search.ranker_model.ranklib_ranker import RankLib
ranker_mapping = {
    'Ranklib': RankLib,
}