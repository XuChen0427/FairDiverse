from .ranklib_ranker import RankLib
ranker_mapping = {
    'Ranklib': RankLib,
}